# Removed Badges

<table>
  <tr><th valign="top" align="left">Act of Kindness</th></tr>
  <tr><th valign="top" align="left">Throwback</th></tr>
</table>

# Day Streak Badges

<table>
  <tr>
    <td align=left>Badge</td>
    <td align=left>Way you can earn it</td>
  </tr>
    <tr><th valign="top" align="left">7 Day Streak</th><th valign="top" align="left">Achieving a 7 day hacking streak</th></tr>
    <tr><th valign="top" align="left">30 Day Streak</th><th valign="top" align="left">Achieving a 30 day hacking streak</th></tr>
    <tr><th valign="top" align="left">90 Day Streak</th><th valign="top" align="left">Achieving a 90 day hacking streak</th></tr>
    <tr><th valign="top" align="left">180 Day Streak</th><th valign="top" align="left">Achieving a 180 day hacking streak</th></tr>
    <tr><th valign="top" align="left">365 Day Streak</th><th valign="top" align="left">Achieving a 365 day hacking streak</th></tr>
    <tr><th valign="top" align="left">500 Day Streak</th><th valign="top" align="left">Achieving a 500 day hacking streak</th></tr>
    <tr><th valign="top" align="left">750 Day Streak</th><th valign="top" align="left">Achieving a 750 day hacking streak</th></tr>
    <tr><th valign="top" align="left">1000 Day Streak</th><th valign="top" align="left">Achieving a 1000 day hacking streak</th></tr>
    <tr><th valign="top" align="left">1250 Day Streak</th><th valign="top" align="left">Achieving a 1250 day hacking streak</th></tr>
    <tr><th valign="top" align="left">1500 Day Streak</th><th valign="top" align="left">Achieving a 1500 day hacking streak</th></tr>
</table>

# Weekly Leagues Badges

<table>
  <tr>
    <td align=left>Badge</td>
    <td align=left>Way you can earn it</td>
  </tr>
    <tr><th valign="top" align="left">Bronze League</th><th valign="top" align="left">Bronze League 1st place</th></tr>
    <tr><th valign="top" align="left">Silver League</th><th valign="top" align="left">Silver League 1st place</th></tr>
    <tr><th valign="top" align="left">Gold League</th><th valign="top" align="left">Gold League 1st place</th></tr>
    <tr><th valign="top" align="left">Diamond League</th><th valign="top" align="left">Diamond League 1st place</th></tr>
    <tr><th valign="top" align="left">Saphire League</th><th valign="top" align="left">Saphire League 1st place</th></tr>
</table>

# Other Badges

<table>
  <tr>
    <td align=left>Badge</td>
    <td align=left>Way you can earn it</td>
  </tr>
  <tr><th valign="top" align="left">King</th><th valign="top" align="left">Win a King of the Hill Game</th></tr>
  <tr><th valign="top" align="left">Monthly Hacker</th><th valign="top" align="left">Being the top hacker of the month</th></tr>
</table>

# Badges

<table>
  <tr>
    <td align=left>Badge</td>
    <td align=left>Room(s)</td>
  </tr>
    <tr><th valign="top" align="left">/opt/m0th3r</th><th valign="top" align="left">
      Mother's Secret  - https://tryhackme.com/room/codeanalysis
    </th></tr>
    <tr><th valign="top" align="left">3 Million Legend</th><th valign="top" align="left">
      TryHack3M: Bricks Heist  - https://tryhackme.com/room/tryhack3mbricksheist<br/>
      TryHack3M: Burg3r Bytes - https://tryhackme.com/room/burg3rbytes<br/>
      TryHack3M: Sch3Ma D3Mon - https://tryhackme.com/room/sch3mad3mon<br/>
      TryHack3M: Subscribe - https://tryhackme.com/room/subscribe<br/>
      TryHack3M: TriCipher Summit - https://tryhackme.com/room/tryhack3mencryptionchallenge
    </th></tr>
    <tr><th valign="top" align="left">Advent of Cyber 2023</th><th valign="top" align="left">
      Advent of Cyber 2023 - https://tryhackme.com/room/adventofcyber2023
    </th></tr>
    <tr><th valign="top" align="left">Advent of Cyber 2024</th><th valign="top" align="left">
      Advent of Cyber 2024 - https://tryhackme.com/room/adventofcyber2024
    </th></tr>
    <tr><th valign="top" align="left">Advent of Cyber 3</th><th valign="top" align="left">
      Advent of Cyber 3 (2021) - https://tryhackme.com/room/adventofcyber3
    </th></tr>
    <tr><th valign="top" align="left">Advent of Cyber 4</th><th valign="top" align="left">
      Advent of Cyber 2022 - https://tryhackme.com/room/adventofcyber4
    </th></tr>
    <tr><th valign="top" align="left">ADversary</th><th valign="top" align="left">
      Persisting Active Directory - https://tryhackme.com/room/persistingad
    </th></tr>
    <tr><th valign="top" align="left">Authentication Striker</th><th valign="top" align="left">
      Hammer - https://tryhackme.com/room/hammer
    </th></tr>
    <tr><th valign="top" align="left">Blue</th><th valign="top" align="left">
      Blue - https://tryhackme.com/room/blue
    </th></tr>
    <tr><th valign="top" align="left">Boogeyman Slayer</th><th valign="top" align="left">
      Boogeyman 3 - https://tryhackme.com/room/boogeyman3
    </th></tr>
    <tr><th valign="top" align="left">Burp'ed</th><th valign="top" align="left">
      Burp Suite: Extensions - https://tryhackme.com/room/burpsuiteextensions
    </th></tr>
    <tr><th valign="top" align="left">Calculated Risk</th><th valign="top" align="left">
      Risk Management - https://tryhackme.com/room/seriskmanagement
    </th></tr>
    <tr><th valign="top" align="left">cat linux.txt</th><th valign="top" align="left">
      Linux Fundamentals Part 1 - https://tryhackme.com/room/linuxfundamentalspart1<br/>
      Linux Fundamentals Part 2 - https://tryhackme.com/room/linuxfundamentalspart2<br/>
      Linux Fundamentals Part 3 - https://tryhackme.com/room/linuxfundamentalspart3
    </th></tr>
    <tr><th valign="top" align="left">Changing Hats</th><th valign="top" align="left">
      Atomic Bird Goes Purple #2 - https://tryhackme.com/room/atomicbirdtwo
    </th></tr>
    <tr><th valign="top" align="left">Christmas 2019</th><th valign="top" align="left">
      Advent of Cyber 1 [2019] - https://tryhackme.com/room/25daysofchristmas
    </th></tr>
    <tr><th valign="top" align="left">Client-Side Champ</th><th valign="top" align="left">
      Whats Your Name? - https://tryhackme.com/room/whatsyourname
    </th></tr>
    <tr><th valign="top" align="left">Cyber Ready</th><th valign="top" align="left">
      Training Impact on Teams - https://tryhackme.com/room/training
    </th></tr>
    <tr><th valign="top" align="left">Defrosted Five</th><th valign="top" align="left">
      Advent of Cyber '24 Side Quest - https://tryhackme.com/room/adventofcyber24sidequest
    </th></tr>
    <tr><th valign="top" align="left">Diplodocker</th><th valign="top" align="left">
      Container Vulnerabilities - https://tryhackme.com/room/containervulnerabilitiesDG
    </th></tr>
    <tr><th valign="top" align="left">Docker</th><th valign="top" align="left">
      The Docker Rodeo - https://tryhackme.com/room/dockerrodeo
    </th></tr>
    <tr><th valign="top" align="left">ELKsquisite</th><th valign="top" align="left">
      Slingshot - https://tryhackme.com/room/slingshot
    </th></tr>
    <tr><th valign="top" align="left">Friday Fixer</th><th valign="top" align="left">
      Friday Overtime - https://tryhackme.com/room/fridayovertime
    </th></tr>
    <tr><th valign="top" align="left">Handle the Disgruntled</th><th valign="top" align="left">
      Disgruntled - https://tryhackme.com/room/disgruntled
    </th></tr>
    <tr><th valign="top" align="left">Hash Cracker</th><th valign="top" align="left">
      Crack The Hash Level 2  - https://tryhackme.com/room/crackthehash
    </th></tr>
    <tr><th valign="top" align="left">HoloLive</th><th valign="top" align="left">
      Holo - https://tryhackme.com/room/hololive
    </th></tr>
    <tr><th valign="top" align="left">HTTP Smuggler</th><th valign="top" align="left">
      El Bandito - https://tryhackme.com/room/elbandito
    </th></tr>
    <tr><th valign="top" align="left">Ice</th><th valign="top" align="left">
      Ice - https://tryhackme.com/room/ice
    </th></tr>
    <tr><th valign="top" align="left">Intro to Web Hacking</th><th valign="top" align="left">
      Command Injection - https://tryhackme.com/room/oscommandinjection
    </th></tr>
    <tr><th valign="top" align="left">Introduction to Security Engineering</th><th valign="top" align="left">
      Security Engineer Intro - https://tryhackme.com/room/securityengineerintro
    </th></tr>
    <tr><th valign="top" align="left">Intruder Alert</th><th valign="top" align="left">
      SigHunt - https://tryhackme.com/room/sighunt
    </th></tr>
    <tr><th valign="top" align="left">Investigations</th><th valign="top" align="left">
      Cyber Defense - https://tryhackme.com/path/outline/blueteam
    </th></tr>
    <tr><th valign="top" align="left">Just have to deal with it</th><th valign="top" align="left">
      Cyber Crisis Management - https://tryhackme.com/room/cybercrisismanagement
    </th></tr>
    <tr><th valign="top" align="left">Linux PrivEsc</th><th valign="top" align="left">
      Linux PrivEsc - https://tryhackme.com/room/linuxprivesc<br/>
      Linux PrivEsc Arena - https://tryhackme.com/room/linuxprivescarena
    </th></tr>
    <tr><th valign="top" align="left">Logging Legend</th><th valign="top" align="left">
      Intro to Log Analysis - https://tryhackme.com/room/introtologanalysis
    </th></tr>
    <tr><th valign="top" align="left">Malware Analysis</th><th valign="top" align="left">
      Dynamic Analysis: Debugging - https://tryhackme.com/room/advanceddynamicanalysis
    </th></tr>
    <tr><th valign="top" align="left">Manic Monday</th><th valign="top" align="left">
      Monday Monitor - https://tryhackme.com/room/mondaymonitor
    </th></tr>
    <tr><th valign="top" align="left">Metasploitable</th><th valign="top" align="left">
      Metasploit: Meterpreter - https://tryhackme.com/room/meterpreter
    </th></tr>
    <tr><th valign="top" align="left">Mr. Robot</th><th valign="top" align="left">
      Mr Robot CTF - https://tryhackme.com/room/mrrobot
    </th></tr>
    <tr><th valign="top" align="left">Network and System Security</th><th valign="top" align="left">
      Auditing and Monitoring - https://tryhackme.com/room/auditingandmonitoringse
    </th></tr>
    <tr><th valign="top" align="left">Networking Nerd</th><th valign="top" align="left">
      Extending Your Network - https://tryhackme.com/room/extendingyournetwork
    </th></tr>
    <tr><th valign="top" align="left">OhSINT</th><th valign="top" align="left">
      OhSINT - https://tryhackme.com/room/ohsint
    </th></tr>
    <tr><th valign="top" align="left">Overpassed</th><th valign="top" align="left">
      Overpass - https://tryhackme.com/module/overpass
    </th></tr>
    <tr><th valign="top" align="left">OWASP Top 10</th><th valign="top" align="left">
      OWASP Top 10 - https://tryhackme.com/room/owasptop10<br/>
      OWASP Top 10 - 2021 - https://tryhackme.com/room/owasptop102021
    </th></tr>
    <tr><th valign="top" align="left">Packet Master</th><th valign="top" align="left">
      TShark Challenge II: Directory - https://tryhackme.com/room/tsharkchallengestwo
    </th></tr>
    <tr><th valign="top" align="left">Pentester Tools</th><th valign="top" align="left">
      Pentesting Tools - https://tryhackme.com/module/pentestingtools
    </th></tr>
    <tr><th valign="top" align="left">Pentesting Principles</th><th valign="top" align="left">
      Principles of Security - https://tryhackme.com/room/principlesofsecurity
    </th></tr>
    <tr><th valign="top" align="left">Phishing</th><th valign="top" align="left">
      The Greenholt Phish - https://tryhackme.com/room/phishingemails5fgjlzxc
    </th></tr>
    <tr><th valign="top" align="left">Pipeline Lieutenant</th><th valign="top" align="left">
      CI/CD and Build Security - https://tryhackme.com/room/cicdandbuildsecurity
    </th></tr>
    <tr><th valign="top" align="left">Red Teamer of the Month</th><th valign="top" align="left">
      Red Team Capstone Challenge - https://tryhackme.com/room/redteamcapstonechallenge
    </th></tr>
    <tr><th valign="top" align="left">Security Awareness</th><th valign="top" align="left">
      Common Attacks - https://tryhackme.com/room/commonattacks
    </th></tr>
    <tr><th valign="top" align="left">Shield Apprentice</th><th valign="top" align="left">
      FlareVM: Arsenal of Tools - https://tryhackme.com/room/flarevmarsenaloftools
    </th></tr>
    <tr><th valign="top" align="left">Skilled Navigator</th><th valign="top" align="left">
      Eviction - https://tryhackme.com/room/eviction
    </th></tr>
    <tr><th valign="top" align="left">SNOW/OFF</th><th valign="top" align="left">
      Advent of Cyber '23 Side Quest  - https://tryhackme.com/room/adventofcyber23sidequest
    </th></tr>
    <tr><th valign="top" align="left">Software Security</th><th valign="top" align="left">
      OWASP API Security Top 10 - 2 - https://tryhackme.com/room/owaspapisecuritytop10d0
    </th></tr>
    <tr><th valign="top" align="left">SPLUNKing</th><th valign="top" align="left">
      Splunk: Data Manipulation - https://tryhackme.com/room/splunkdatamanipulation
    </th></tr>
    <tr><th valign="top" align="left">SQL Slayer</th><th valign="top" align="left">
      Advanced SQL Injection - https://tryhackme.com/room/advancedsqlinjection
    </th></tr>
    <tr><th valign="top" align="left">Sword Apprentice</th><th valign="top" align="left">
      SQLMap: The Basics - https://tryhackme.com/room/sqlmapthebasics
    </th></tr>
    <tr><th valign="top" align="left">System Sniffer</th><th valign="top" align="left">
      File Inclusion, Path Traversal - https://tryhackme.com/room/filepathtraversal
    </th></tr>
    <tr><th valign="top" align="left">Terminated!</th><th valign="top" align="left">
      Intro to IaC - https://tryhackme.com/room/introtoiac
    </th></tr>
    <tr><th valign="top" align="left">The Best Responder</th><th valign="top" align="left">
      Lessons Learned - https://tryhackme.com/room/lessonslearned
    </th></tr>
    <tr><th valign="top" align="left">The Course Awakens</th><th valign="top" align="left">
      Introduction to DevSecOps - https://tryhackme.com/room/introductiontodevsecops
    </th></tr>
    <tr><th valign="top" align="left">The Return of the Yeti</th><th valign="top" align="left">
      Frosteau Busy with Vim  - https://tryhackme.com/room/busyvimfrosteau<br/>
      Snowy ARMageddon  - https://tryhackme.com/room/armageddon2r<br/>
      The Bandit Surfer  - https://tryhackme.com/room/surfingyetiiscomingtotown<br/>
      The Return of the Yeti  - https://tryhackme.com/room/adv3nt0fdbopsjcap
    </th></tr>
    <tr><th valign="top" align="left">Threat Hunter</th><th valign="top" align="left">
      Hunt Me I: Payment Collectors - https://tryhackme.com/room/paymentcollectors
    </th></tr>
    <tr><th valign="top" align="left">To benign or not benign?</th><th valign="top" align="left">
      Benign - https://tryhackme.com/room/benign
    </th></tr>
    <tr><th valign="top" align="left">Webbed</th><th valign="top" align="left">
      HTTP in Detail - https://tryhackme.com/room/httpindetail
    </th></tr>
    <tr><th valign="top" align="left">WindCorp</th><th valign="top" align="left">
      WindCorp - https://tryhackme.com/module/windcorp
    </th></tr>
    <tr><th valign="top" align="left">Windows Priv Esc</th><th valign="top" align="left">
      Windows PrivEsc Arena - https://tryhackme.com/room/windowsprivescarena
    </th></tr>
    <tr><th valign="top" align="left">Wireshark</th><th valign="top" align="left">
      Wireshark 101 - https://tryhackme.com/room/wireshark
    </th></tr>
    <tr><th valign="top" align="left">World Wide Web</th><th valign="top" align="left">
      Putting it all together - https://tryhackme.com/room/puttingitalltogether
    </th></tr>
    <tr><th valign="top" align="left">Wreath</th><th valign="top" align="left">
      Wreath - https://tryhackme.com/room/wreath
    </th></tr>
</table>
